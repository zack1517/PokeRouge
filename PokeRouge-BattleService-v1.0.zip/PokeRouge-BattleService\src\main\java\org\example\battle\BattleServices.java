package org.example.battle;

import org.example.data.GameData;
import org.example.model.Player;
import org.example.model.Pokemon;

import java.util.Optional;
import java.util.Random;

/**
 * {@link BattleService} 的静态工厂与战斗环境助手。
 *
 * <p>负责：按训练家与野生精灵创建一场新的对战；围绕玩家等级生成遭遇（野生等级浮动、
 * 从数据注册表随机挑选野生精灵）。调用方（主界面/控制器）通过本工厂获取
 * {@link BattleService}，而无需依赖具体实现类 {@link BattleEngine}。</p>
 */
public final class BattleServices {

    private BattleServices() {
        // 工具类，禁止实例化
    }

    // ------------------------------------------------------------------
    // 创建对战
    // ------------------------------------------------------------------

    /**
     * 创建一场默认随机源的新对战。
     *
     * @param player 玩家（当前出战精灵必须存活，否则抛异常）
     * @param wild   野生精灵（必须非倒下）
     * @return 一个已就绪的 {@link BattleService} 实例
     * @throws NullPointerException     参数为 {@code null}
     * @throws IllegalArgumentException 玩家无可用出战精灵，或野生精灵无效
     */
    public static BattleService newBattle(Player player, Pokemon wild) {
        return new BattleEngine(player, wild);
    }

    /**
     * 创建一场可指定随机源的新对战（便于测试复现）。
     *
     * @param player 玩家（当前出战精灵必须存活，否则抛异常）
     * @param wild   野生精灵（必须非倒下）
     * @param random 随机源
     * @return 一个已就绪的 {@link BattleService} 实例
     * @throws NullPointerException     参数为 {@code null}
     * @throws IllegalArgumentException 玩家无可用出战精灵，或野生精灵无效
     */
    public static BattleService newBattle(Player player, Pokemon wild, Random random) {
        return new BattleEngine(player, wild, random);
    }

    // ------------------------------------------------------------------
    // 遭遇环境
    // ------------------------------------------------------------------

    /**
     * 野生等级围绕玩家等级浮动（[level-2, level+2] 内随机，最低 2）。
     *
     * @param playerLevel 玩家等级
     * @return 野生精灵建议等级
     */
    public static int wildLevelAround(int playerLevel) {
        return Math.max(2, playerLevel + (int) (Math.random() * 5) - 2);
    }

    /**
     * 从数据注册表随机挑选一只野生精灵。
     *
     * @param aroundLevel 目标等级（用于构造精灵个体）
     * @return 野生精灵；注册表中无野生池数据时返回 {@link Optional#empty()}
     */
    public static Optional<Pokemon> randomWild(int aroundLevel) {
        java.util.List<String> pool = GameData.instance().wildPool();
        if (pool.isEmpty()) {
            return Optional.empty();
        }
        String id = pool.get((int) (Math.random() * pool.size()));
        return GameData.instance().createPokemon(id, aroundLevel);
    }
}
